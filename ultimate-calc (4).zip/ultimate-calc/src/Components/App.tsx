import React, { useState } from 'react'
import Calc from './Calc'
import Bmi from './Bmi';
import { Routes, Route, Link } from 'react-router-dom';


function App() {

  return (
    <div className="w-screen bg-blue-100
     p-10 h-screen overflow-hidden flex flex-col items-center">
      <Routes>
        <Route path='/' element={<Calc />} />
        <Route path='/bmi' element={<Bmi />} />
      </Routes>
    </div>
  )
}

export default App
