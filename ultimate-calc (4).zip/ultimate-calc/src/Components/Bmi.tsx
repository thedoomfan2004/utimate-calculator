import { useState } from 'react'
import { Link } from 'react-router-dom'
import arrow from '../assets/arrow.png'

export default function Bmi() {


  const [bmi, setBmi] = useState<any>()  
  const [height, setHeight] = useState<any>()
  const [weight, setWeight] = useState<any>()

  function handleClick() {
    setBmi(Math.round(weight / ((height / 100) * (height / 100))))
  }


  function handleClear() {
    setBmi('')
    setHeight('')
    setWeight('')
  }

  function handleHeight(e: any) {
    setHeight(e.target.value)
  }

  function handleWeight(e: any) {
    setWeight(e.target.value)
  }

  // function changeMethod(e: any) {
  //   if(e.target.value == 'kg') {
  //     setWeight(weight * 2.2046)
  //   } else if(e.target.value == 'cm') {
  //     setHeight(height / 2.54)
  //   }
  // }

  return (
    <div className='w-72 shadow-2xl relative grid bg-black text-white
     rounded-xl grid-rows-4 grid-cols-4 md:w-3/4 gap-2 h-fit p-2'> 
      <div className="border w-full col-span-3 bg-transparent
       flex items-center rounded-xl p-2 text-sm h-14">
        Your BMI is: {bmi}
      </div>
      <button className='flex items-center justify-center cursor-pointer  text-white'>
        <div onClick={handleClear} className="h-14 flex items-center
         justify-center bg-red-700 hover:brightness-75 rounded-xl w-full">
            clear
        </div>
      </button>
      <input type="text" value={height} onChange={handleHeight} className='col-span-3 bg-transparent flex items-center p-2 rounded-xl border' 
      placeholder='Your Height' />
      <button value={'cm'}  className="hover:brightness-75 
      rounded-xl flex items-center justify-center bg-lime-600">
        CM
      </button>
      <input type="text" value={weight} onChange={handleWeight} className='col-span-3 bg-transparent flex items-center p-2 rounded-xl border' 
        placeholder='Your Weight' />
      <button value={'kg'} className="hover:brightness-75 rounded-xl 
      flex items-center justify-center bg-lime-600">
        KG
      </button>
      <button onClick={handleClick} className='col-span-4 hover:brightness-75 bg-orange-400 rounded-xl flex items-center justify-center'>
       Calculate
      </button>
      <Link to='/' className='absolute flex flex-col items-center
       text-sm -right-20 rounded-xl bg-white text-black p-3'>
        Regular
        <br />
        <img src={arrow} alt="" className='w-3' />
        <img src={arrow} alt="" className='w-3 rotate-180' />
      </Link>
      <button className='absolute flex flex-col items-center
       text-sm -right-16 rounded-xl top-20 bg-white text-black p-3'>
        Age
        <br />
        <img src={arrow} alt="" className='w-3' />
        <img src={arrow} alt="" className='w-3 rotate-180' />
      </button>
      <button className='absolute flex flex-col items-center
       text-sm -right-24 rounded-xl top-40 bg-white text-black p-3'>
        Scientific
        <br />
        <img src={arrow} alt="" className='w-3' />
        <img src={arrow} alt="" className='w-3 rotate-180' />
      </button>
    </div>
  )
}


